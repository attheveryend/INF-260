/**
 * Alex Leduc
 * Connect 4 Computer opponent
 * 
 */
import java.util.*;

public class opponent {
	Random gen = new Random();
    //============================================================================= default constructor
    public opponent() {
    	
    }
    
    //=============================================================================		nextMove
    public int nextMove(board theboard){
    	int move;
    	do{
    		move = Math.abs(gen.nextInt() %7 );
    	}while(theboard.getNextRow(move)==6 );
    	return(move);
    }//end nextMove
    
    
}